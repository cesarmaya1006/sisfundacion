module FontAwesome
  module Sass
    VERSION = "6.7.2".freeze
  end
end
